<?php
session_start();
include('config/config.php');

// Initialize $_SESSION['cart'] if it's not set
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

// Check if the necessary data is provided
if (isset($_POST['productId'], $_POST['productName'], $_POST['productPrice'], $_POST['quantity'])) {
    // Extract data from $_POST
    $productId = $_POST['productId'];
    $productName = $_POST['productName'];
    $productPrice = $_POST['productPrice'];
    $quantity = $_POST['quantity'];

    // Generate a unique customer_id
    $customer_id = generateCustomerId();

    // Insert order into rpos_kiosk_orders
    $customer_name = "Walk-In Customer"; // Label customer as "Walk-In Customer"
    $insert_order_query = "INSERT INTO rpos_kiosk_orders (prod_id, customer_id, customer_name, prod_name, prod_price, prod_qty, order_status, created_at) VALUES (?, ?, ?, ?, ?, ?, 'Pending', NOW())";
    $stmt = $mysqli->prepare($insert_order_query);
    $stmt->bind_param('ssssds', $productId, $customer_id, $customer_name, $productName, $productPrice, $quantity);
    $stmt->execute();
    $stmt->close();

    // Fetch ingredients for the ordered product
    $ingredientQuery = "SELECT * FROM rpos_product_ingredients WHERE prod_id = ?";
    $ingredientStmt = $mysqli->prepare($ingredientQuery);
    $ingredientStmt->bind_param('s', $productId);
    $ingredientStmt->execute();
    $ingredientResult = $ingredientStmt->get_result();

    // Update inventory based on the fetched ingredients
    while ($ingredient = $ingredientResult->fetch_object()) {
        $ingredientName = $ingredient->ing_name;
        $ingredientQuantity = intval($ingredient->quantity);

        // Update inventory for the current ingredient
        $updateInventoryQuery = "UPDATE rpos_inventory SET qty = qty - ? WHERE ing_name = ?";
        $updateInventoryStmt = $mysqli->prepare($updateInventoryQuery);
        $updateInventoryStmt->bind_param('is', $ingredientQuantity, $ingredientName);
        $updateInventoryStmt->execute();

        if ($updateInventoryStmt->affected_rows <= 0) {
            die('Error: Failed to update inventory for ingredient: ' . $ingredientName);
        }
        $updateInventoryStmt->close();
    }

    // Add item to cart
    $item = array(
        'prod_id' => $productId,
        'prod_name' => $productName,
        'prod_price' => $productPrice,
        'quantity' => $quantity,
        'customer_id' => $customer_id // Add the generated customer_id to the item array
    );

    // Add item to cart session variable
    $_SESSION['cart'][] = $item;

    // Send success response
    echo "Product added to cart successfully!";
}

// Function to generate a unique customer_id
function generateCustomerId()
{
    // Generate a unique alphanumeric code for customer_id
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $length = 8;
    $customer_id = '';
    for ($i = 0; $i < $length; $i++) {
        $customer_id .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $customer_id;
}

// Function to calculate total price of items in cart
function calculateTotalPrice()
{
    $totalPrice = 0;
    if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $item) {
            $totalPrice += $item['prod_price'] * $item['quantity']; // Assuming the correct column name is 'productPrice'
        }
    }
    return $totalPrice;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add to Cart</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    <!-- Main content -->
    <div class="container">
        <h2>Orders</h2>
        <div class="row">
            <div class="col-md-8">
                <!-- Display order details if cart is not empty -->
                <?php if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) { ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Product Name</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Total</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($_SESSION['cart'] as $key => $item) { ?>
                                <tr>
                                    <td><?php echo $item['prod_name']; ?></td>
                                    <td>₱ <?php echo $item['prod_price']; ?></td>
                                    <td><?php echo $item['quantity']; ?></td>
                                    <td>₱ <?php echo $item['prod_price'] * $item['quantity']; ?></td>
                                    <td>
                                        <!-- Button to remove item -->
                                        <form action="remove_from_cart.php" method="post">
                                            <input type="hidden" name="index" value="<?php echo $key; ?>">
                                            <button type="submit" class="btn btn-danger btn-sm">Remove</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                <?php } ?>
            </div>
            <div class="col-md-4">
                <!-- Order summary -->
                <h4>Order Summary</h4>
                <p>Total Items: <?php echo isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0; ?></p>
                <p>Total Price: ₱<?php echo calculateTotalPrice(); ?></p>
                <!-- Checkout button -->
                <form action="payments.php" method="post">
                    <button type="submit" class="btn btn-success">Checkout</button>
                </form>
            </div>
        </div>

        <!-- Back button -->
        <div class="mt-3">
            <a href="kiosk.php" class="btn btn-primary">Back to Ordering</a>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>