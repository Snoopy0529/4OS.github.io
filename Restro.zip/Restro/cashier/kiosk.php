<?php
session_start();
include('config/config.php');
include('config/checklogin.php');
check_login();

require_once('partials/_head.php');
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<body>
    <?php require_once('partials/_sidebar.php'); ?>

    <div class="main-content">
        <!-- Top navbar -->
        <?php require_once('partials/_topnav.php'); ?>
        <!-- Header -->
        <div style="background-image: url(../admin/assets/img/theme/resto-bg.jpg); background-size: cover;" class="header pb-8 pt-5 pt-md-8">
            <span class="mask bg-gradient-dark opacity-8"></span>
            <div class="container-fluid">
                <div class="header-body"></div>
            </div>
        </div>
        <div class="container-fluid mt-8">
            <div class="container">
                <div class="row">
                    <?php
                    // Fetch and display products
                    $ret = "SELECT * FROM rpos_products ORDER BY created_at DESC";
                    $stmt = $mysqli->prepare($ret);
                    $stmt->execute();
                    $res = $stmt->get_result();
                    while ($prod = $res->fetch_object()) {
                    ?>
                        <div class="col-md-4">
                            <div class="card mb-4 shadow-sm">
                                <img src="<?php echo ($prod->prod_img) ? "../admin/assets/img/products/$prod->prod_img" : "../admin/assets/img/products/default.jpg"; ?>" class="card-img-top" alt="Product Image">
                                <div class="card-body">
                                    <h5 class="k-card-title"><?php echo $prod->prod_name; ?></h5>
                                    <p class="k-card-text">Product Code: <?php echo $prod->prod_code; ?></p>
                                    <p class="k-card-text">Price: ₱ <?php echo $prod->prod_price; ?></p>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="addToCart('<?php echo $prod->prod_id; ?>', '<?php echo $prod->prod_name; ?>', <?php echo $prod->prod_price; ?>)">Add to Cart</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Quantity Modal -->
    <div class="modal fade" id="quantityModal" tabindex="-1" aria-labelledby="quantityModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="quantityModalLabel">Enter Quantity</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <label for="quantityInput">Quantity:</label>
                    <input type="number" id="quantityInput" class="form-control" value="1">
                    <input type="hidden" id="productId" name="productId">
                    <input type="hidden" id="productName" name="productName">
                    <input type="hidden" id="productPrice" name="productPrice">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" id="confirmQuantityBtn" class="btn btn-primary">Confirm</button>
                </div>
            </div>
        </div>
    </div>

    <!-- View Orders Button -->
    <a href="add_to_cart.php" class="btn btn-primary btn-floating" style="position: fixed; bottom: 20px; right: 20px;">View Orders</a>

    <!-- Footer -->
    <?php require_once('partials/_footer.php'); ?>

    <!-- Additional Scripts -->
    <script>
        function addToCart(productId, productName, productPrice, quantity) {
            $('#productId').val(productId);
            $('#productName').val(productName);
            $('#productPrice').val(productPrice);
            $('#quantityModal').modal('show');
        }

        $(document).ready(function() {
            $('#confirmQuantityBtn').click(function() {
                var quantity = parseInt($('#quantityInput').val());

                if (isNaN(quantity) || quantity <= 0) {
                    alert('Please enter a valid quantity.');
                    return;
                }

                var productId = $('#productId').val();
                var productName = $('#productName').val();
                var productPrice = $('#productPrice').val();
                console.log("Debug - Product ID:", productId);
                console.log("Debug - Product Name:", productName);
                console.log("Debug - Product Price:", productPrice);
                console.log("Debug - Quantity:", quantity);

                // Insert order details into the database
                $.ajax({
                    url: 'add_to_cart.php',
                    method: 'POST',
                    data: {
                        productId: productId,
                        productName: productName,
                        productPrice: productPrice,
                        quantity: quantity
                    },
                    success: function(response) {
                        console.log(response);
                        // Optional: Refresh the page or update the UI after successful addition to cart
                        // window.location.reload(); // Uncomment this line if you want to refresh the page after adding to cart
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                        alert('Failed to add product to cart. Please try again later.');
                    }
                });

                // Close the modal
                $('#quantityModal').modal('hide');
            });
        });
    </script>

</body>

</html>