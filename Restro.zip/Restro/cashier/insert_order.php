<?php
session_start();
include('config/config.php');
include('config/code-generator.php');

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if the necessary data is provided
    if (isset($_POST['productId']) && isset($_POST['productName']) && isset($_POST['productPrice']) && isset($_POST['quantity'])) {
        // Extract data from the POST request
        $productId = $_POST['productId'];
        $productName = $_POST['productName'];
        $productPrice = $_POST['productPrice'];
        $quantity = $_POST['quantity'];

        // Prepare the SQL statement to insert the order details into the database
        $stmt = $mysqli->prepare("INSERT INTO rpos_kiosk_orders (prod_id, prod_name, prod_price, prod_qty, order_status, created_at) VALUES (?, ?, ?, ?, ?, ?)");

        // Bind parameters
        $stmt->bind_param("ssssss", $productId, $productName, $productPrice, $quantity, $orderStatus, $createdAt);

        // Set order status to empty (not paid)
        $orderStatus = '';

        // Get current date and time
        $createdAt = date('Y-m-d H:i:s');

        // Execute the SQL statement
        if ($stmt->execute()) {
            // Order details inserted successfully
            echo "Order details inserted successfully!";
        } else {
            // Failed to insert order details
            echo "Error: " . $mysqli->error;
        }

        // Close the prepared statement
        $stmt->close();
    } else {
        // Required data not provided
        echo "Required data not provided!";
    }
} else {
    // Invalid request method
    echo "Invalid request method!";
}
