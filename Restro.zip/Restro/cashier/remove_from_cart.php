<?php
session_start();
include('config/config.php');

// Check if index is set and is a valid integer
if (isset($_POST['index']) && filter_var($_POST['index'], FILTER_VALIDATE_INT) !== false) {
    // Get the index of the item to be removed
    $index = $_POST['index'];

    // Remove the item from the cart array
    if (isset($_SESSION['cart'][$index])) {
        // Get the product id of the item to be removed
        $productId = $_SESSION['cart'][$index]['prod_id'];

        // Delete the record from the database
        $delete_query = "DELETE FROM rpos_kiosk_orders WHERE prod_id = ? AND order_status = 'Pending'";
        $stmt = $mysqli->prepare($delete_query);
        $stmt->bind_param('s', $productId);
        $stmt->execute();
        $stmt->close();

        // Unset the item from the session cart
        unset($_SESSION['cart'][$index]);

        // Reorder the keys in the array to avoid gaps
        $_SESSION['cart'] = array_values($_SESSION['cart']);
    }

    // Redirect back to the add_to_cart.php page
    header("Location: add_to_cart.php");
    exit();
} else {
    // Redirect back to the add_to_cart.php page with an error message
    $_SESSION['error'] = "Invalid item index.";
    header("Location: add_to_cart.php");
    exit();
}
