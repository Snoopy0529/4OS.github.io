<?php

function updateProductAvailability($mysqli)
{
    $query = "SELECT p.prod_id, IFNULL(MIN(CAST(i.qty AS SIGNED)), 0) AS min_qty
            FROM rpos_products p
            LEFT JOIN rpos_product_ingredients pi ON p.prod_id = pi.prod_id
            LEFT JOIN rpos_inventory i ON pi.ing_name = i.ing_name
            GROUP BY p.prod_id";

    $result = $mysqli->query($query);

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $prod_id = $row['prod_id'];
            $min_qty = $row['min_qty'];

            if ($min_qty <= 0) {
                $availability = 'Out of Stock';
            } else if ($min_qty < 50) {
                $availability = 'Low on Stock';
            } else {
                $availability = 'Available';
            }

            // Update product availability in the database
            $update_query = "UPDATE rpos_products SET availability = ? WHERE prod_id = ?";
            $stmt = $mysqli->prepare($update_query);
            $stmt->bind_param('ss', $availability, $prod_id);
            $stmt->execute();
            $stmt->close();
        }
    }
}

function updateProductAvailability1($mysqli, $orderDetailsResult)
{
    while ($orderDetail = $orderDetailsResult->fetch_object()) {
        // Fetch quantity of ingredients from rpos_inventory
        $fetchQuantityQuery = "SELECT SUM(qty) AS total_qty FROM rpos_inventory WHERE ing_name IN (SELECT ing_name FROM rpos_product_ingredients WHERE prod_id = ?)";
        $fetchQuantityStmt = $mysqli->prepare($fetchQuantityQuery);
        if (!$fetchQuantityStmt) {
            die('Error: Failed to prepare fetch quantity statement: ' . $mysqli->error);
        }
        $fetchQuantityStmt->bind_param('s', $orderDetail->prod_id);
        $fetchQuantityStmt->execute();
        $fetchQuantityResult = $fetchQuantityStmt->get_result();

        // Check if quantity is fetched successfully
        if ($fetchQuantityResult) {
            if ($fetchQuantityResult->num_rows > 0) {
                $quantityData = $fetchQuantityResult->fetch_assoc();
                $totalQuantity = $quantityData['total_qty'];

                // Determine availability based on total quantity
                if ($totalQuantity <= 0) {
                    $availability = 'Out of Stock';
                } else if ($totalQuantity < 50) {
                    $availability = 'Low on Stock';
                } else {
                    $availability = 'Available';
                }

                // Update product availability
                $updateAvailabilityQuery = "UPDATE rpos_products SET availability = ? WHERE prod_id = ?";
                $updateAvailabilityStmt = $mysqli->prepare($updateAvailabilityQuery);
                if (!$updateAvailabilityStmt) {
                    die('Error: Failed to prepare update statement: ' . $mysqli->error);
                }
                $updateAvailabilityStmt->bind_param('ss', $availability, $orderDetail->prod_id);
                $updateAvailabilityStmt->execute();

                if ($updateAvailabilityStmt->affected_rows <= 0) {
                    // Handle update failure
                    die('Error: Failed to update product availability for product: ' . $orderDetail->prod_id);
                }
                $updateAvailabilityStmt->close();
            } else {
                // Handle case where quantity is not found
                die('Error: No quantity found for product: ' . $orderDetail->prod_id);
            }
        } else {
            // Handle query failure
            die('Error: Failed to execute fetch quantity query');
        }

        $fetchQuantityStmt->close(); // Close fetchQuantityStmt
    }
}
